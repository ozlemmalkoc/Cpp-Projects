#include "MyClass.h"

#include "LogicCircuit.h"
int main()
{
	
	
	LogicCircuit c;
	
	c.readAndBuildArray();
	c.linkArray();
	c.readInputAndRunCircuit();
	

	

}